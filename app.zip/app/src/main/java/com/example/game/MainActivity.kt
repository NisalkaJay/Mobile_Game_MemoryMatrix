package com.example.game

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.View.OnClickListener
import android.widget.Button
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.view.forEach
import androidx.lifecycle.lifecycleScope
import com.example.game.databinding.ActivityMainBinding
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity(), OnClickListener {
    // Late-initialized variables for binding, score, result, and user's answer
    private lateinit var binding: ActivityMainBinding
    private var score = 0
    private var result: String = ""
    private var userAnswer: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize binding using ViewBinding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set onClickListeners for each panel and start the game
        binding.apply {
            panel1.setOnClickListener(this@MainActivity)
            panel2.setOnClickListener(this@MainActivity)
            panel3.setOnClickListener(this@MainActivity)
            panel4.setOnClickListener(this@MainActivity)
            startGame()
        }
    }

    // Disable all buttons
    private fun disableButtons() {
        binding.root.forEach { view ->
            if (view is Button) {
                view.isEnabled = false
            }
        }
    }

    // Enable all buttons
    private fun enableButtons() {
        binding.root.forEach { view ->
            if (view is Button) {
                view.isEnabled = true
            }
        }
    }

    // Start the game
    private fun startGame() {
        result = ""
        userAnswer = ""
        disableButtons() // Disable buttons during the game
        lifecycleScope.launch {
            val round = (3..5).random() // Randomize the number of rounds
            repeat(round) {
                delay(400) // Delay for visual effect
                val randomPanel = (1..4).random() // Randomize panel selection
                result += randomPanel // Append panel selection to the result
                val panel = when (randomPanel) {
                    1 -> binding.panel1
                    2 -> binding.panel2
                    3 -> binding.panel3
                    else -> binding.panel4
                }
                val drawableYellow = ActivityCompat.getDrawable(this@MainActivity, R.drawable.btn_yellow)
                val drawableDefault = ActivityCompat.getDrawable(this@MainActivity, R.drawable.btn_state)
                panel.background = drawableYellow // Change panel background
                delay(1000) // Delay for visual effect
                panel.background = drawableDefault // Reset panel background
            }
            runOnUiThread {
                enableButtons() // Enable buttons after rounds are completed
            }
        }
    }

    // Animation for losing the game
    private fun loseAnimation() {
        binding.apply {
            score = 0 // Reset score to zero
            tvScore.text = "0" // Update score text view
            disableButtons() // Disable buttons during animation
            val drawableLose = ActivityCompat.getDrawable(this@MainActivity, R.drawable.btn_lose)
            val drawableDefault = ActivityCompat.getDrawable(this@MainActivity, R.drawable.btn_state)
            lifecycleScope.launch {
                binding.root.forEach { view ->
                    if (view is Button) {
                        view.background = drawableLose // Change button background during animation
                        delay(300) // Delay for animation effect
                        view.background = drawableDefault // Reset button background
                    }
                }
                delay(1000) // Delay after animation
                Toast.makeText(this@MainActivity, "Game Over", Toast.LENGTH_SHORT).show()// Display "Game Over" toast message
                startActivity(Intent(this@MainActivity, StartActivity::class.java)) // Redirect to StartActivity
            }
        }
    }

    // Handle button clicks
    override fun onClick(view: View?) {
        view?.let {
            userAnswer += when (it.id) {
                R.id.panel1 -> "1"
                R.id.panel2 -> "2"
                R.id.panel3 -> "3"
                R.id.panel4 -> "4"
                else -> ""
            }
            if (userAnswer == result) {
                Toast.makeText(this@MainActivity, "Won the round ", Toast.LENGTH_SHORT).show() // Display win message
                score++ // Increment score
                binding.tvScore.text = score.toString() // Update score text view
                startGame() // Start a new round
            } else if (userAnswer.length >= result.length) {
                loseAnimation() // Trigger lose animation if user's answer is incorrect
            }
        }
    }
}
